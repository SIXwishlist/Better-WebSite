
      <div class="pull-right">
        <div class="btn-group">
          <a href="admin/account.php"><button class="btn btn-primary">
            <?php echo $_SESSION["usename"]; ?>
          </button></a>
          <a href="admin/do.php?value=exit"><button class="btn btn-primary dropdown-toggle">
            Exit
          </button></a>
          </div>
          </div>