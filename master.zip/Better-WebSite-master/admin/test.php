<?php
include("functions/checkLogin.php");
include("functions/head.php");
?>
<div class="row">
    <div class="col-sm-4" style="background-color:darkblue;">
      <div class="tile purple">
        <h3 class="title">Purple Tile</h3>
        <p>Hello Purple, this is a colored tile.</p>
      </div>
    </div>
    <div class="col-sm-4" style="background-color:darkorange;">
      <div class="tile red">
        <h3 class="title">Red Tile</h3>
        <p>Hello Red, this is a colored tile.</p>
      </div>
    </div>
    <div class="col-sm-4" style="background-color:darkgreen;">
      <div class="tile orange">
        <h3 class="title">Orange Tile</h3>
        <p>Hello Orange, this is a colored tile.</p>
      </div>
    </div>
  </div>
  </div>
<?php
include("functions/footer.php");
?>